# Konane
